#ifndef MYHEADER
#define MYHEADER

void setupGame();
void game(std::string nick, int boardlen, std::vector<std::vector<int>> &playerBoard, std::vector<std::vector<int>> &AIBoard);


#endif 