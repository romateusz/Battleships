#include <iostream>
#include <vector>
#include "terminal.h"

int main()
{
    setupGame();
    return 0;
}